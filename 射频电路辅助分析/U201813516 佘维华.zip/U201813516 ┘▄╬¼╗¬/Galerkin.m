clear
close all


%%%%%%%%%%%����
w=3e-3;
d=3e-3;
e1=10/36/pi/10^9;
u1=4*pi/10^7;
e2=1/36/pi/10^9;
u2=4*pi/10^7;

interval=0.5;
M=2;
N=2;

KZ=[];
s=0;
%%%%%%%ѭ��
for f=(10e9:1e9:40e9)
ff=f
syms kz;

%����
k1=2*pi*f*sqrt(e1*u1);
k2=2*pi*f*sqrt(e2*u2);
alpha = (-50:interval:50); 
gamma1=sqrt(abs(alpha.^2+kz^2-k1^2));
gamma2=sqrt(abs(alpha.^2+kz^2-k2^2));

%������
Jxna=zeros(N,length(alpha));
Jzna=zeros(N,length(alpha));
Jxma=zeros(M,length(alpha));
Jzma=zeros(M,length(alpha));
parfor aa=1:length(alpha)
    for nn=1:N
        Jxna(nn,aa)=(-1)^nn*0.5*(-1j)*besselj(0,alpha(aa)+nn*pi)-(-1)^nn*0.5*(-1j)*besselj(0,alpha(aa)-nn*pi);
        Jzna(nn,aa)=(-1)^(nn-1)*0.5*besselj(0,alpha(aa)+(nn-1)*pi)+(-1)^(nn-1)*0.5*besselj(0,alpha(aa)-(nn-1)*pi);
    end
end
parfor aa=1:length(alpha)
    for mm=1:M
        Jxma(mm,aa)=(-1)^mm*0.5*(-1j)*besselj(0,alpha(aa)+mm*pi)-(-1)^mm*0.5*(-1j)*besselj(0,alpha(aa)-mm*pi);
        Jzma(mm,aa)=(-1)^(mm-1)*0.5*besselj(0,alpha(aa)+(mm-1)*pi)+(-1)^(mm-1)*0.5*besselj(0,alpha(aa)-(mm-1)*pi);
    end
end

%b
b11=1j*alpha*((k2^2-kz^2)/(k1^2-kz^2)-1);
b22=-b11;
b12=2*pi*f*u2*gamma1/kz.*(gamma2./gamma1+u1/u2*(k2^2-kz^2)/(k1^2-kz^2)*tanh(gamma1*d));
b21=2*pi*f*e2*gamma1/kz.*(gamma2./gamma1+e1/e2*(k2^2-kz^2)/(k1^2-kz^2)*coth(gamma1*d));

b_det=b11.*b22-b12.*b21;
F1=2*pi*f*u1*gamma1.*tanh(gamma1*d)/(k1^2-kz^2)*(-1j);

%G
G11=(F1.*b22+kz/(k1^2-kz^2)*alpha.*b12)./b_det;
G12=b12./b_det;
G21=gamma1.*(F1.*b21+kz/(k1^2-kz^2)*alpha.*b11)./b_det;
G22=gamma1.*b11./b_det;

%K
K11 = zeros(M,N);
K12 = zeros(M,N);
K21 = zeros(M,N);
K22 = zeros(M,N);
parfor aa=1:length(alpha)
    temp=Jxna';
    K11=K11+interval*Jzma(:,aa)*G11(aa)*temp(aa,:);  
    temp=Jzna';
    K12=K12+interval*Jzma(:,aa)*G11(aa)*temp(aa,:);   
    temp=Jxna';
    K21=K21+interval*Jxma(:,aa)*G11(aa)*temp(aa,:);    
    temp=Jzna';
    K22=K22+interval*Jxma(:,aa)*G11(aa)*temp(aa,:);
end

K_det=K(1,1)*K(2,2)*K(3,3)*K(4,4)-K(1,2)*K(2,3)*K(3,4)*K(4,1)+K(1,3)*K(2,4)*K(3,1)*K(4,2)-K(1,4)*K(2,1)*K(3,2)*K(4,3)+K(4,1)*K(3,2)*K(2,3)*K(1,4)-K(4,2)*K(3,3)*K(2,4)*K(1,1)+K(4,3)*K(3,4)*K(2,1)*K(1,2)-K(4,4)*K(3,1)*K(2,2)*K(1,3)+K(1,1)*K(2,3)*K(3,4)*K(4,2)-K(1,3)*K(2,4)*K(3,2)*K(4,1)+K(1,4)*K(2,2)*K(3,1)*K(4,3)-K(1,2)*K(2,1)*K(3,3)*K(4,4)+K(4,1)*K(3,3)*K(2,4)*K(1,2)-K(4,3)*K(3,4)*K(2,2)*K(1,1)+K(1,4)*K(3,2)*K(2,1)*K(1,3)-K(4,2)*K(3,1)*K(2,3)*K(1,4)+K(1,1)*K(2,4)*K(3,2)*K(4,3)-K(1,4)*K(2,2)*K(3,3)*K(4,1)+K(1,2)*K(2,3)*K(3,1)*K(4,4)-K(1,3)*K(2,1)*K(3,4)*K(4,2)+K(4,1)*K(3,4)*K(2,2)*K(1,3)-K(4,4)*K(3,2)*K(2,3)*K(1,1)+K(4,2)*K(3,3)*K(2,1)*K(1,4)-K(4,3)*K(3,1)*K(2,4)*K(1,2);
s=vpasolve(K_det,kz,[s,3e3]);
if (size(s) == [0,1])
  KZ=[KZ,0];
else
  KZ=[KZ,s];
end


%%%%%%ѭ������
end
plot(1:length(KZ),KZ);


