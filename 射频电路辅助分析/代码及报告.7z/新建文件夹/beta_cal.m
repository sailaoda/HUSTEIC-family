close all;
clear;
clc;
tic;


%% ��������
%΢���߲���
w = 3e-3;   
d = 3e-3;
eps0 = 1/36/pi/10^9;
miu0 = 4*pi/10^7;
epsr = 10;
miur = 1;
%�������
alpha = -50:0.5:50;         %��������
freq = 10e9*2*pi;           %�����Ƶ��
M = 2;                      %����������
N = 2;                      %����������
%�������
syms beta



%% ����������
Jz = zeros(1,length(alpha),N);
Jx = zeros(1,length(alpha),M);
for k = 1:N
    Jz(:,:,k) = (-1)^(k-1)/2*( besselj(0,alpha+(k-1)*pi) + besselj(0,alpha-(k-1)*pi));
end
for k = 1:M
    Jx(:,:,k) = (-1)^k/(2j)*( besselj(0,alpha+k*pi) - besselj(0,alpha-k*pi) );
end

%% ��������
k1 = freq*sqrt(eps0*epsr*miu0*miur);    %�ĵ�
k2 = freq*sqrt(eps0*miu0);              %����

gamma1 = sqrt(alpha.^2+beta^2-k1^2);
gamma2 = sqrt(alpha.^2+beta^2-k2^2);
%����b������
temp = (k2^2-beta^2)/(k1^2-beta^2);
b_11 = 1j*alpha*(temp-1);
b_22 = -b_11;
b_12 = freq*miu0/beta*gamma1.*(gamma2./gamma1+miur*temp*tanh(gamma1*d));
b_21 = freq*eps0/beta*gamma1.*(gamma2./gamma1+epsr*temp*coth(gamma1*d));
% b_12 = freq*miu0*gamma1/beta*(gamma2./gamma1+miur*temp*tanh(gamma1*d));
% b_21 = freq*eps0*gamma1/beta*(gamma2/gamma1+epsr*temp*coth(gamma1*d));
Det = b_11.*b_22-b_12.*b_21;
F1 = (freq*miu0*miur*gamma1).*tanh(gamma1*d)/(1j*(k1^2-beta^2));
    
%����G����
temp = alpha*beta/(k1^2-beta^2);
G_11 = (F1.*b_22+temp.*b_12)./Det;
G_12 = b_12./Det;
G_21 = gamma2.*(F1.*b_21+temp.*b_11)./Det;
G_22 = gamma2.*b_11./Det;
% G = zeros(1,length(alpha),2,2);
% G(:,:,1,1) = (F1.*b_22+temp.*b_12)./det;
% G(:,:,1,2) = b_12./det;
% G(:,:,2,1) = gamma2.*(F1.*b_21+temp.*b_11)./det;
% G(:,:,2,2) = gamma2.*b_11./det;

%����K����
%��ʼ��

K_11 = sym(zeros(1,N,M));
K_12 = sym(zeros(1,N,M));
K_21 = sym(zeros(1,N,M));
K_22 = sym(zeros(1,N,M));
for n = 1:N
    for m = 1:M
        K_11(1,m,n) = sum(Jz(:,:,m).*G_11.*Jx(:,:,n))*0.5;
        K_12(1,m,n) = sum(Jz(:,:,m).*G_12.*Jz(:,:,n))*0.5;
        K_21(1,m,n) = sum(Jx(:,:,m).*G_21.*Jx(:,:,n))*0.5;
        K_22(1,m,n) = sum(Jx(:,:,m).*G_22.*Jz(:,:,n))*0.5;
    end
end

% Q = sym(zeros(2*N,2*M));
% 
% for m = 1:M
%     for n = 1:N
%         Q(2*(m-1)+1,n) = K_11(1,m,n);
%     end
%     for n = 1:N
%         Q(2*(m-1)+1,n+N) = K_12(1,m,n);
% %         Q = [Q,K_12(1,m,n)];
%     end
%     for n = 1:N
%         Q(2*(m-1)+2,n) = K_21(1,m,n);
% %         Q = [Q,K_21(1,m,n)];
%     end
%     for n = 1:N
%         Q(2*(m-1)+2,n+N) = K_22(1,m,n);
% %         Q = [Q,K_22(1,m,n)];
%     end
% end
exp = (K_11(1,1,1)*K_21(1,1,2)-K_11(1,1,2)*K_21(1,1,1))*(K_12(1,2,1)*K_22(1,2,2)-K_12(1,2,2)*K_22(1,2,1))-(K_11(1,1,1)*K_22(1,1,1)-K_12(1,1,1)*K_21(1,1,1))*(K_11(1,2,2)*K_22(1,2,2)-K_12(1,2,2)*K_21(1,2,2))+(K_11(1,1,1)*K_22(1,1,2)-K_12(1,1,2)*K_21(1,1,1))*(K_11(1,2,2)*K_22(1,2,1)-K_12(1,2,1)*K_21(1,2,2))+(K_11(1,1,2)*K_22(1,1,1)-K_12(1,1,1)*K_21(1,1,2))*(K_11(1,2,1)*K_22(1,2,2)-K_12(1,2,2)*K_21(1,2,1))-(K_11(1,1,2)*K_22(1,1,2)-K_12(1,1,2)*K_21(1,1,2))*(K_11(1,2,1)*K_22(1,2,1)-K_12(1,2,1)*K_21(1,2,1))+(K_12(1,1,1)*K_22(1,1,2)-K_12(1,1,2)*K_22(1,1,1))*(K_11(1,2,1)*K_21(1,2,2)-K_11(1,2,2)*K_21(1,2,1));
% exp = K_11(1,1,1)*K_22(1,1,1)-K_12(1,1,1)*K_21(1,1,1);

% exp = det(Q);
b = vpasolve(exp,beta,[550,800]);
% k_eff = (b/freq)^2/eps0/miu0;

toc;

% beta_ads = freq*sqrt(k_eff*eps0*miu0);


